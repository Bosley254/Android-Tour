package com.example.thetour

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {
    var firebase = Firebase
    var editUsername : EditText ?= null
    var editEmail : EditText ?= null
    var editPhoneNo : EditText ?= null
    var editPassword : EditText ?= null
    var buttonSignup : Button ?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editUsername = findViewById(R.id.EdtUserS)
        editEmail = findViewById(R.id.EdtEmailS)
        editPhoneNo = findViewById(R.id.EdtPhoneS)
        editPassword = findViewById(R.id.EdtPass)
        buttonSignup = findViewById(R.id.BtnSignUp)

        buttonSignup!!.setOnClickListener{
            val username = editUsername!!.text.toString().trim()
            val emails = editEmail!!.text.toString().trim()
            val phoneNumber = editPhoneNo!!.text.toString().trim()
            val password = editPassword!!.text.toString().trim()
            //check if user has submitted empty fields
            if (username.isEmpty()){
                editUsername!!.setError("Please Enter ur Choice Username")
                editUsername!!.requestFocus()
            }else if (emails.isEmpty()){
                editEmail!!.setError("Please Enter ur Email")
                editEmail!!.requestFocus()
            }else if (phoneNumber.isEmpty()){
                editPhoneNo!!.setError("Please Enter ur Phone NO")
                editPhoneNo!!.requestFocus()
            }else if (password.isEmpty()){
                editPassword!!.setError("Please Enter ur Choice Password")
                editPassword!!.requestFocus()
            }else{
                //proceed to save the info
                //start by creating the User Object
                val userData = SignUp(username,emails,phoneNumber,password)
                //create a reference to store data
                val reference = FirebaseDatabase.getInstance().
                        getReference().child("SignUp/$username")
                //start saving user data
                reference.setValue(userData).addOnCompleteListener{
                        task->
                    if (task.isSuccessful){
                        Toast.makeText(applicationContext, "Your Info saved successfully", Toast.LENGTH_SHORT).show()
                    }else{
                        Toast.makeText(applicationContext, "Info NOt Saved-- Try Again", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}