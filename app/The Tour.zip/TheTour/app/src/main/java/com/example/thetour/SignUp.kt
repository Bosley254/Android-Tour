package com.example.thetour

class SignUp {
    var username:String=""
    var emails:String=""
    var phoneNO:String=""
    var password:String=""

    constructor(Username:String, Email:String, PhoneNO:String, Password:String){
        this.username = Username
        this.emails = Email
        this.phoneNO = PhoneNO
        this.password= Password
    }
        constructor()
    }

